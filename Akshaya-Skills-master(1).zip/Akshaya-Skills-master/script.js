// ==================== PRODUCT DATA ====================
const products = [
    {
        id: 1,
        name: "Kanjivaram Silk Saree",
        price: 8500,
        category: "kanjivaram",
        type: "silk",
        description: "Traditional Kanjivaram silk with intricate gold zari work",
        image: "images/saree1.jpg",
        features: ["Pure Kanjivaram Silk", "Gold Zari Border", "Traditional Motifs", "Handwoven"]
    },
    {
        id: 2,
        name: "Banarasi Pattu Saree",
        price: 6500,
        category: "banarasi",
        type: "silk",
        description: "Elegant Banarasi pattu with rich brocade work",
        image: "images/saree2.jpg",
        features: ["Banarasi Silk", "Brocade Work", "Traditional Design", "Wedding Special"]
    },
    {
        id: 3,
        name: "Pure Mysore Silk",
        price: 4500,
        category: "silk",
        type: "silk",
        description: "Lightweight pure Mysore silk perfect for any occasion",
        image: "images/saree3.jpg",
        features: ["Mysore Silk", "Lightweight", "Elegant Border", "Versatile"]
    },
    {
        id: 4,
        name: "Gadwal Silk Saree",
        price: 7200,
        category: "silk",
        type: "silk",
        description: "Classic Gadwal silk with contrasting pallu",
        image: "images/saree4.jpg",
        features: ["Gadwal Silk", "Contrasting Pallu", "Temple Border", "Premium Quality"]
    },
    {
        id: 5,
        name: "Uppada Silk Saree",
        price: 5800,
        category: "silk",
        type: "silk",
        description: "Delicate Uppada silk with beautiful jamdani work",
        image: "images/saree5.jpg",
        features: ["Uppada Silk", "Jamdani Work", "Lightweight", "Elegant Design"]
    },
    {
        id: 6,
        name: "Kanjivaram Wedding Saree",
        price: 12500,
        category: "kanjivaram",
        type: "silk",
        description: "Premium wedding special Kanjivaram with heavy zari",
        image: "images/saree6.jpg",
        features: ["Bridal Collection", "Heavy Zari Work", "Rich Silk", "Exclusive Design"]
    },
    {
        id: 7,
        name: "Cotton Silk Saree",
        price: 3200,
        category: "silk",
        type: "cotton-silk",
        description: "Comfortable cotton silk blend for daily elegance",
        image: "images/saree7.jpg",
        features: ["Cotton Silk Blend", "Comfortable", "Daily Wear", "Affordable"]
    },
    {
        id: 8,
        name: "Tussar Silk Saree",
        price: 4800,
        category: "silk",
        type: "silk",
        description: "Natural Tussar silk with ethnic prints",
        image: "images/saree8.jpg",
        features: ["Tussar Silk", "Natural Texture", "Ethnic Prints", "Eco-friendly"]
    }
];

// ==================== GLOBAL VARIABLES ====================
let cart = [];
let currentDetailProduct = null;

// ==================== INITIALIZATION ====================
// Load products when page loads
document.addEventListener('DOMContentLoaded', function() {
    renderProducts(products);
    updateCartCount();
});

// ==================== RENDER PRODUCTS FUNCTION ====================
/**
 * Renders product cards to the DOM
 * @param {Array} filteredProducts - Array of products to display
 */
function renderProducts(filteredProducts) {
    const container = document.getElementById('productsContainer');
    container.innerHTML = '';

    // Check if there are products to display
    if (filteredProducts.length === 0) {
        container.innerHTML = '<div class="col-12 text-center"><p class="text-muted">No products found matching your criteria.</p></div>';
        return;
    }

    // Loop through products and create cards
    filteredProducts.forEach(product => {
        const col = document.createElement('div');
        col.className = 'col-md-6 col-lg-4 col-xl-3';
        
        col.innerHTML = `
            <div class="product-card">
                <div class="product-img-wrapper">
                    <img src="${product.image}" alt="${product.name}" class="product-img">
                    ${product.price > 10000 ? '<span class="product-badge">Premium</span>' : ''}
                </div>
                <div class="product-body">
                    <h5 class="product-title">${product.name}</h5>
                    <p class="product-description">${product.description}</p>
                    <div class="product-price">₹${product.price.toLocaleString()}</div>
                    <div class="product-actions">
                        <button class="btn-primary-custom" onclick="addToCart(${product.id})">
                            <i class="fas fa-cart-plus me-1"></i>Add to Cart
                        </button>
                        <button class="btn-outline-custom" onclick="viewDetails(${product.id})">
                            <i class="fas fa-eye me-1"></i>Details
                        </button>
                    </div>
                    <button class="btn btn-primary-custom mt-2 w-100" onclick="buyNow(${product.id})">
                        <i class="fas fa-bolt me-1"></i>Buy Now
                    </button>
                </div>
            </div>
        `;
        
        container.appendChild(col);
    });
}

// ==================== FILTER PRODUCTS FUNCTION ====================
/**
 * Filters products based on selected category
 * @param {string} filterType - Type of filter to apply
 */
function filterProducts(filterType) {
    let filteredProducts = [];

    // Remove active class from all filter buttons
    document.querySelectorAll('.filter-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // Add active class to clicked button
    event.target.classList.add('active');

    // Apply filter logic
    switch(filterType) {
        case 'all':
            filteredProducts = products;
            break;
        case 'silk':
            filteredProducts = products.filter(p => p.type === 'silk');
            break;
        case 'kanjivaram':
            filteredProducts = products.filter(p => p.category === 'kanjivaram');
            break;
        case 'banarasi':
            filteredProducts = products.filter(p => p.category === 'banarasi');
            break;
        case 'budget':
            filteredProducts = products.filter(p => p.price < 5000);
            break;
        case 'premium':
            filteredProducts = products.filter(p => p.price >= 10000);
            break;
        default:
            filteredProducts = products;
    }

    // Re-render products with filtered results
    renderProducts(filteredProducts);
}

// ==================== ADD TO CART FUNCTION ====================
/**
 * Adds a product to the shopping cart
 * @param {number} productId - ID of the product to add
 */
function addToCart(productId) {
    // Find the product by ID
    const product = products.find(p => p.id === productId);
    
    if (!product) return;

    // Check if product already exists in cart
    const existingItem = cart.find(item => item.id === productId);

    if (existingItem) {
        // Increase quantity if already in cart
        existingItem.quantity += 1;
    } else {
        // Add new item to cart
        cart.push({
            ...product,
            quantity: 1
        });
    }

    // Update cart display
    updateCartCount();
    updateCartDisplay();

    // Show success feedback
    showNotification(`${product.name} added to cart!`);
}

// ==================== UPDATE CART COUNT ====================
/**
 * Updates the cart badge counter
 */
function updateCartCount() {
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    document.getElementById('cartCount').textContent = totalItems;
}

// ==================== UPDATE CART DISPLAY ====================
/**
 * Updates the cart modal with current cart items
 */
function updateCartDisplay() {
    const cartItemsContainer = document.getElementById('cartItems');
    const cartTotalElement = document.getElementById('cartTotal');

    // Check if cart is empty
    if (cart.length === 0) {
        cartItemsContainer.innerHTML = `
            <div class="empty-cart">
                <i class="fas fa-shopping-cart"></i>
                <p>Your cart is empty</p>
            </div>
        `;
        cartTotalElement.textContent = 'Total: ₹0';
        return;
    }

    // Render cart items
    cartItemsContainer.innerHTML = '';
    let total = 0;

    cart.forEach(item => {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;

        const cartItemDiv = document.createElement('div');
        cartItemDiv.className = 'cart-item';
        cartItemDiv.innerHTML = `
            <img src="${item.image}" alt="${item.name}" class="cart-item-img">
            <div class="cart-item-details">
                <div class="cart-item-title">${item.name}</div>
                <div class="cart-item-price">₹${item.price.toLocaleString()}</div>
            </div>
            <div class="quantity-controls">
                <button class="quantity-btn" onclick="updateQuantity(${item.id}, -1)">-</button>
                <span class="mx-2">${item.quantity}</span>
                <button class="quantity-btn" onclick="updateQuantity(${item.id}, 1)">+</button>
            </div>
            <div class="ms-3">
                <div class="fw-bold">₹${itemTotal.toLocaleString()}</div>
                <button class="remove-btn mt-2" onclick="removeFromCart(${item.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </div>
        `;
        cartItemsContainer.appendChild(cartItemDiv);
    });

    // Update total
    cartTotalElement.textContent = `Total: ₹${total.toLocaleString()}`;
}

// ==================== UPDATE QUANTITY FUNCTION ====================
/**
 * Updates the quantity of an item in the cart
 * @param {number} productId - ID of the product
 * @param {number} change - Amount to change quantity (+1 or -1)
 */
function updateQuantity(productId, change) {
    const item = cart.find(i => i.id === productId);
    
    if (!item) return;

    item.quantity += change;

    // Remove item if quantity becomes 0
    if (item.quantity <= 0) {
        removeFromCart(productId);
        return;
    }

    // Update displays
    updateCartCount();
    updateCartDisplay();
}

// ==================== REMOVE FROM CART FUNCTION ====================
/**
 * Removes an item from the cart
 * @param {number} productId - ID of the product to remove
 */
function removeFromCart(productId) {
    cart = cart.filter(item => item.id !== productId);
    updateCartCount();
    updateCartDisplay();
    showNotification('Item removed from cart');
}

// ==================== VIEW DETAILS FUNCTION ====================
/**
 * Opens product detail modal
 * @param {number} productId - ID of the product
 */
function viewDetails(productId) {
    const product = products.find(p => p.id === productId);
    
    if (!product) return;

    // Store current product for "Add to Cart" in modal
    currentDetailProduct = product;

    // Populate modal with product details
    document.getElementById('detailTitle').textContent = product.name;
    document.getElementById('detailImage').src = product.image;
    document.getElementById('detailPrice').textContent = `₹${product.price.toLocaleString()}`;
    document.getElementById('detailDescription').textContent = product.description;

    // Populate features list
    const featuresList = document.getElementById('detailFeatures');
    featuresList.innerHTML = '';
    product.features.forEach(feature => {
        const li = document.createElement('li');
        li.textContent = feature;
        featuresList.appendChild(li);
    });

    // Show modal using Bootstrap's modal API
    const detailModal = new bootstrap.Modal(document.getElementById('detailModal'));
    detailModal.show();
}

// ==================== ADD TO CART FROM DETAIL MODAL ====================
/**
 * Adds product to cart from the detail modal
 */
function addToCartFromDetail() {
    if (currentDetailProduct) {
        addToCart(currentDetailProduct.id);
        // Close the detail modal
        const detailModal = bootstrap.Modal.getInstance(document.getElementById('detailModal'));
        detailModal.hide();
    }
}

// ==================== BUY NOW FUNCTION ====================
/**
 * Quick checkout - adds to cart and opens cart modal
 * @param {number} productId - ID of the product
 */
function buyNow(productId) {
    addToCart(productId);
    // Open cart modal
    const cartModal = new bootstrap.Modal(document.getElementById('cartModal'));
    cartModal.show();
}

// ==================== CHECKOUT FUNCTION ====================
/**
 * Handles checkout process
 */
function checkout() {
    if (cart.length === 0) {
        alert('Your cart is empty!');
        return;
    }

    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    // Simulate checkout process
    alert(`Thank you for your order!\n\nTotal Amount: ₹${total.toLocaleString()}\n\nThis is a demo checkout. In a real application, this would redirect to a payment gateway.`);
    
    // Clear cart after checkout
    cart = [];
    updateCartCount();
    updateCartDisplay();
    
    // Close cart modal
    const cartModal = bootstrap.Modal.getInstance(document.getElementById('cartModal'));
    cartModal.hide();
    
    showNotification('Order placed successfully!');
}

// ==================== NOTIFICATION FUNCTION ====================
/**
 * Shows a temporary notification message
 * @param {string} message - Message to display
 */
function showNotification(message) {
    // Create notification element
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: #28a745;
        color: white;
        padding: 15px 25px;
        border-radius: 5px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        z-index: 9999;
        animation: slideIn 0.3s ease;
    `;
    notification.textContent = message;
    
    // Add to document
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);